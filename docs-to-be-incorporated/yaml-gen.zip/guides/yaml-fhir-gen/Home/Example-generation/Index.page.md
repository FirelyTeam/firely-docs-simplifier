## {{page-title}}

YAMLGEN has several ways to speed up generation of randomized data. This can be useful
for example generation or test data.

{{index:children}}