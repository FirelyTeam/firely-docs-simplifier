## YAMLGEN

_Want to create a FHIR resource? All you need to know is YAML_

### Introduction
With YAMLGEN you can create FHIR resources by just writing YAML. It is the quickest way to define FHIR profiles and example resources. It is especially handy when you quickly need to create example data.

YamlGen will help you generate resources without having to maintain much more verbose xml or json files and can even produce multiple resources from a single instruction
.

### Try it
You can try out YAMLGEN in our [Playground](/yamlgen). And you can start 
with any public scope (project or package).

### Accellerators
Accellerators help you to write even shorter Yaml.
The following Yaml example:
```
Patient:
    id: 4
    name:
        given: John
```
can be written as follows with accellerators:
```
Patient/4:
    name.given: John
```

Have a look at the documentation pages on the left to see how you can use YamlGen to support you in your work.


