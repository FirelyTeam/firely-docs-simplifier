## {{page-title}}

These sub-pages cover how your guide is wired together: page topics and scope, guide-wide variables, reusable templates, and page layout. Setting these up well saves you repeating yourself across pages and keeps the guide consistent as it grows.