# Simplifier IG Help

This help text can help find out how to put the Simplifier Implementation Guide Editor to maximum use. We follow the principle of 'eating your own dog food' here: this help text is an Implementation Guide itself, so you can read the source on the left and see the effect on the right.

In the nodes below, you see examples on how to use each topic of the Editor. In the editor panel you see exactly what we wrote, and in the preview on the right you see the result. Just as it will happen when you write your own Implementation Guide.

Please see the [best practices on writing a FHIR Implementation Guide](https://build.fhir.org/ig/FHIR/ig-guidance/branches/master/best-practice.html) for more general guidance on what your Guide should cover.
