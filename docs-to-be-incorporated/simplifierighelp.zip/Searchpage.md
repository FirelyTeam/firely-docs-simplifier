### Search page

You can create your own search page, by creating a Google Custom Search Engine at https://cse.google.com. Make sure you specify the URL of your IG as the domain to be searched.

Paste the code in your Search page, like the code below:

<script async src="https://cse.google.com/cse.js?cx=008188271495507206974:2fzrgudt1vf"></script>
<div class="gcse-search"></div>

Your search page will only return results once Google has indexed your IG. This can take a moment after you have created it. 