## Field joins

<div style='padding: 5px; background-color: #ADA; margin: 10px 0px;'>
  This syntax comes with FQL 3. Which will be available with the june 2021 release of Simplifier and Firely Terminal 2.2.
</div>

Unlike like SQL, FQL has to deal with the fact that data does not come in the shape of a table. Yet, you need the same kind of
output that an SQL statement would have produced. With SQL you know nested data will be in a different table, but with FHIR or any tree
structured data, your nested data will often be part of the same resource. When you want to merge nested data in SQL, you use 
a table join, and logically, FQL needs a field based join.

Imagine you want to produce a row for your patients, with their name and identifier. But it's possible that they have more than
one identifier, which in this case should produce a separate row, with each row having a unique identifier, but possible a repeated first and last name.

```c#
from Patient
select
    name.family,
    name.given[0],
    join identifier.value
```

It doesn't matter in which order the joins are written, besides the column ordering the output is the same. So the following produces the same rows and values, just in a different order
```c#
from Patient
select
    join identifier.value,
    name.family,
    name.given[0]
```

### Joining on multiple values
It is quite common to join on more than one field. Especially when you want to join on several values of a sub node. A good example is
`Patient.name`. To achieve a join over multiple values, you can use the unwrapping syntax (technically known as a group dereference):

```c#
from Patient
select
    identifier[0].value,
    join name { family, given[0] }
```
This query will produce a row per pair of name values, and repeating the identifier for each of those rows.

### Inner Joins
The join keyword is actually a shorthand for `inner join`. So where ever you write `join` you can equally write `inner join`. An inner join produces a row when both sides of the join have a value.

For SQL that would produce rows where both tables 'meet', but with FQL, the meeting already took place, since you are joining with 
values or sub values  of the current row. The effect of an inner join is therefore mostly visible in the sense that it will skip 
rows that has no values for the field after the join. If you want a row regardless, use the left join. See below

### Left joins
A left join differs from an inner join, in that it starts out with the left table of a join. With FQL that means that a field join
on a current row, will always show the current row, regardless of whether there are values in the join field.

### Right joins
For field joins there is no such thing as a right join. The explanation under `inner join` helps to see why a `right join` on a field level has no meaning: if there is a field on the right side, there must be a row on the left side since the field is part of that row.

