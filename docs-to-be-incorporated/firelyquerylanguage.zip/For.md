## For clause
For basic single field selections, a path like FhirPath statement is usually good enough.
But there are cases, where you want to reach several fields that are nested deeper. And especiially if you want to pair them, selecting them separately will not work.

## Grouping

This example here will produce a separate list of given names and a list of family names. 
```c#
from Patient        
select 
    name.given,
    name.family
```

If this list grows longer or if your path is deeper, you might choose a `for` statement to 
```c#
from Patient
select
    for name select { given, family }
```

This will produce similar output to the previous statement: all fields (given and family) will be added to the top level of your output.

## Pairing
Because in most cases, you want to pair the results, you will usually want to group them. You can do this by defining
with a named structure, in this case 'items':
```c#
from Patient
select
    for name select
    items: {
        given,
        family
    }
```



