# Real world examples
{{index:current}}