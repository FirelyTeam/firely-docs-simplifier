# Syntax

{{index:current}}

