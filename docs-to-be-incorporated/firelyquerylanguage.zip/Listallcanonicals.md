## List all canonicals

### All canonicals
```c#
from StructureDefinition
select url
```
Listing all (the only one) canonical in this project)
@```
	from StructureDefinition
	select url
```

