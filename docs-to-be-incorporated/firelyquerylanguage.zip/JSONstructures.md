## JSON structures
The FQL syntax allows you to put JSON blocks almost anywhere in your select statement.
This allows grouping of fields, but also renaming of existing fields in the original data.

### Renaming
This example shows you how you can rename the names of a patient:

```c#
from Patient
select
    firstname: name.given,
    lastname: name.family
```

@```
    from Patient
    select
        firstname: name.given,
        lastname: name.family
```


### Grouping
This example shows you how you can group fields:

```c#
from Patient
select
    metadata: {
        id,
        meta.profile
    }

```
when you define a named group, you can nest to any depth. The data cursor will not descend. So with the `metadata` structure above, you still access fields from the root of the resource. To have the cursor descend into the data, instead of your structure, see the `for` clause.

