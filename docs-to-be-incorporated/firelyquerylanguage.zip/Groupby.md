## Group by

<div style='padding: 5px; background-color: #ADA; margin: 10px 0px;'>
  This syntax comes with FQL 3. Which will be available with the june 2021 release of Simplifier and Firely Terminal 2.2.
</div>

FQL allows you to group results with a `group by` clause, which is quite similar to an SQL group by. But there are differences.
However, the basic syntax of the group by clause is the same.

```c#
  from Patient
  group by name.family
  select family
```
As you can see, the `group by` precedes the `select` statement, to allow concatenation or pipelining of results. 

### Aggregation
Aggregation functions already exists in FhirPath, which is the inner language used by FQL to get values. And so a typical 
group function like `count()' can be used on groups, like this:
```c#
from Patient
group by name.family
select family, group.count()
```
But because we are working with tree structured data, many more options are arise, like doing a count over a full FhirPath expression.

```c#
from Patient
group by name.family
select
  family,
  group.name.given.count()
```