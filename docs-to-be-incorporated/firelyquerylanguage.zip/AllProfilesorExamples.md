## All Profiles or Examples

### Details from all Profiles

```c#
from StructureDefinition
where type != 'Extension'
select name, description, status
```

@```
	from StructureDefinition
	where type != 'Extension'
	select name, description, status
```

### Details from all Extensions

```
	from StructureDefinition
	where type = 'Extension'
	select title , description, status, context.expression
```

@```
	from StructureDefinition
	where type = 'Extension'
	select title , description, status, context.expression
```
