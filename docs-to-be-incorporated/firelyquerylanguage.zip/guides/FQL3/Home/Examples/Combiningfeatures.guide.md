# {{page-title}}

### Example  
This query shows you the combination of several features: _where_, _select_, and _for_.

```c#
from
    Patient 
where 
    name[0].family = 'Chalmers'
select 
    for name 
    select greeting: 'Hello ' & given.first() & ' ' & family
    
``` 

Also note that if you move the `for` clause to a top level statement, you will not get rows per resource, but per name.

```c#
from
    Patient 
where 
    name[0].family = 'Chalmers' 
for name select 
{
    greeting: 'Hello ' & given.first() & ' ' & family
} 
```

@```
from
    Patient 
where 
    name[0].family = 'Chalmers' 
for name select 
{
    greeting: 'Hello ' & given.first() & ' ' & family
} 

```