## {{page-title}}

<div style='padding: 5px; background-color: #ADA; margin: 10px 0px;'>
  This syntax comes with FQL 3. Which will be available with the june 2021 release of Simplifier and Firely Terminal 2.2.
</div>

Group Unwrapping  helps you write shorter queries. When you need multiple nested values, Group unwrapping helps you get multiple values from the same sub node.The following query produces a flattened list of the fields name.given and name.family.
```c#
  from Patient 
  select name { given, family }
```
Other than the field names, it would produce the same result as writing 
```c#
  from Patient
  select
    name.given,
    name.family
```

## Complex dereferencing
Note that although derefercing in it's basic form uses dot notation, you can actually use any FhirPath expression.
The following will work:

```c#
  from Patient 
  select
    name.where(use = 'official') { given, family }
```
But in many more complex cases, it might be easier to read when using a `for` expression. The following produces the same output:
```c#
  from Patient
  select 
     for name where use = 'official' 
     select { given, family }
```
See the documentation on for expressions for more information.