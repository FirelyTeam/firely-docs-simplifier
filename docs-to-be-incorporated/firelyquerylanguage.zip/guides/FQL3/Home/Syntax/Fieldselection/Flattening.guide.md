# {{page-title}}
By default FQL produces one table row per resource. But there are clear cases where you don't want that. 


## Rows for deeper values
To create a table from values deeper inside a resource, where it is not relevant for this specific result, to know to which resource
the values belong, you can follow up with a `for` clause instead of starting with a `select`.

Compare this:
```c#
from StructureDefinition
select snapshot.element.constraint.human
```
This will result in one output row _per StructureDefinition_. While the following statement will put all the human readable constraints from all StructureDefinitions in one long table.
```c#
from StructureDefinition
for
    snapshot.element.constraint 
select
    human

```
Example output:
<fql>
    from StructureDefinition
    for
        snapshot.element.constraint 
    select
        human
    take 3
</fql>

In some cases you want to display the array of a single resource as a table. For this purpose a top level `for` clause is also useful:
the select field list will be grouped as one row with three columns for each page.

```c#
from ImplementationGuide
for page.page
select { 
    source,
    title,
    kind
}
```
Example output (top pages from this very Guide):
<fql>
    from ImplementationGuide
    for page.page
    select { 
        source,
        title,
        kind
    }
</fql>



