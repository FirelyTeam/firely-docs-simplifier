## {{page-title}}
The FQL syntax allows you to put JSON blocks almost anywhere in your select statement.
This allows grouping of fields, but also renaming of existing fields in the original data.

### Renaming
This example shows you how you can set the column names containing the first and last name of a patient:

```c#
from Patient
select
    firstname: name.given,
    lastname: name.family
```

@```
    from Patient
    select
        firstname: name.given,
        lastname: name.family
```

