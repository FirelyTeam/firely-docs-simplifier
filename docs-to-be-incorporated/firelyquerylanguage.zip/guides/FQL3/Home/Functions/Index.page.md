## {{page-title}}

The following pages describe FhirPath functions specifically created and tailored to FQL.
They are part of the FQL core infrastructure. So you can use them wherever you use FQL.


{{index:children}}