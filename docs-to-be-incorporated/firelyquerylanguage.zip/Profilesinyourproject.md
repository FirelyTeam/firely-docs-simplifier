## Profiles in your project
Lists the name and canonical from all Profiles available in your project (including referenced packages):

```c#
    using scope
    from 
      StructureDefinition
    select 
      name, url
```