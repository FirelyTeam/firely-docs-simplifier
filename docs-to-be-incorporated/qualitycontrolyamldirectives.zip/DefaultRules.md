## Default Rules

Simplifier provides two default rule series: the minimal and the recommended.

### Minimal series
The minimal series a very small set of rules that we know everyone aggrees on. In this minimal series included the bulk validation rule.
And that in itself is one of the most extensive form of validation you can think of. So in that respect the mimal series is not small.
It is however what the FHIR standard describes that resources should adhere to.

<div class="alert alert-warning">This is a snapshot in time of the QC minimal rules and are subject to change.</div>

```
# This is the minimal rule series

- action: parse
  name: parse-fhir-resources 
  status: "Checking if all FHIR Resource files can be parsed"
  files:
    - /**/*.xml
    - /**/*.json
    - "!package.json"

- name: resource-validation
  status: "Validating resources against the FHIR standard and their 
  profiles"  
  action: validate
  category: Resource
  suppress: 
        - 6005
        - eld-16
        
- action: unique
  name: unique-canonicals
  status: "Checking if all StructureDefinitions have a unique canonical"
  filter: StructureDefinition
  unique: url 
```


### Recommended series
The recommended series is a more opiniated set of rules that we defined, of what we believe a FHIR project should conform too. But we also acknowledge that these are more opiniated, and so we separated them. Here you can think of rules like that every resource should have an id.

<div class="alert alert-warning">This is a snapshot in time of the QC recommended rules and are subject to change.</div>

```
# This is the recommended rule series

- include: minimal

- name: id-mandatory
  status: "Checking if all resources have an id"
  predicate: id.exists()
  error-message: "Resource { {filepath} } must have an id"

- name: no-snapshot
  status: "Checking that structure definitions do not have a pre-generated 
  snapshot"
  filter: StructureDefinition
  predicate: snapshot.element.count() = 0
  error-message: You should not generate a snapshot in your source. Allow 
  the tools to generate the snapshot.
```