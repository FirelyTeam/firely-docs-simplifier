## Predicate

The predicate rule, gives an error for each resource where the predicate evaluates to false.

### Example:
```
- action: predicate
  predicate: id.exists()
  error: This resource does not have an id
```



