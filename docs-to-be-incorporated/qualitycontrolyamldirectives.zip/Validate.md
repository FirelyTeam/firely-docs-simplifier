### Validate

The validate action, validates all resources against the base profiles and their stated base claims, set in `meta.profile`.

```
- action: validate
```